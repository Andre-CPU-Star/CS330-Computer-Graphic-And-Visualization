#include "camera.h"
#include <glm/gtc/matrix_transform.hpp>


Camera::Camera(float aspectRatio, bool isPerspective) : _isPerspective{ isPerspective }, _aspectRatio{aspectRatio} {}

glm::mat4 Camera::GetViewMatrix() {
	return glm::lookAt( _position, _position + _lookDirection, _upDirection);
}

glm::mat4 Camera::GetProjectionMatrix() {
	if (_isPerspective) {
		return glm::perspective(glm::radians(_fieldOfView), _aspectRatio, _nearClip, _farClip);
	}
	return glm::ortho(_aspectRatio, _aspectRatio, -1.0f, 1.0f, _nearClip, _farClip);
}
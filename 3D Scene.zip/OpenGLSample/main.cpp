﻿//List includes are neccessary librarys needed fo projects
#include <iostream>
#include <cstdlib>
#include <GL/glew.h> 
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "camera.h"
#define _USE_MATH_DEFINES
#include <math.h>


using namespace std;
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

//Intitaites startup information
namespace
{
    const char* const WINDOW_TITLE = "Andre Burton Module 6 Assignment";
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;
    struct GLMesh
    {
        GLuint vao;
        GLuint vbos[2];
        GLuint nIndices;
    };

    GLFWwindow* gWindow = nullptr;
    GLMesh gShape1;
    GLMesh gShape2;
    GLMesh gShape3;
    GLMesh gShape4;
    GLMesh gBase;
    GLMesh gLight;
    GLMesh gLight2;
    GLuint gProgramId;
    GLuint gLightProgramId;
    GLuint gLightProgram2Id;
    GLuint gTex1;
    GLuint gTex2;
    GLuint gTex3;
    GLuint gTex4;
    GLuint gTex5;
    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_CLAMP_TO_BORDER;

    Camera gCamera(glm::vec3(-5.0f, 1.5f, 5.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    bool ortho = false;
    GLfloat fov = 45.0f;

    glm::vec3 target = glm::vec3(0.0f, 0.0f, 0.0f);
    glm::vec3 worldUp = glm::vec3(0.0f, 0.0f, 0.0f);
    glm::vec3 cameraFront = glm::normalize(glm::vec3(0.0f, 0.0f, -1.0f));
    glm::mat4 viewMatrix;
    //Position and light basic ifnromation
    glm::vec3 gCenterPosition(1.0f, 0.0f, 0.0f);
    glm::vec3 gCenterScale(1.0f);

    glm::vec3 gShape1Position(-0.6f, 0.6f, -0.2f);
    glm::vec3 gShape1Scale(0.5f);

    glm::vec3 gShape2Position(-1.0f, 0.60f, -0.2f);
    glm::vec3 gShape2Scale(1.0f);

    glm::vec3 gShape3Position(-1.0f, 0.60f, -0.2f);
    glm::vec3 gShape3Scale(1.0f);

    glm::vec3 gShape4Position(-1.0f, 0.60f, -0.2f);
    glm::vec3 gShape4Scale(1.0f);

    glm::vec3 gBasePosition(0.0f, 1.0f, -0.2f);
    glm::vec3 gBaseScale(1.0f);

    glm::vec3 gObjectColor(1.0f, 0.2f, 0.0f);
    glm::vec3 gLightColor(1.0f, 0.8f, 0.5f);
    glm::vec3 gLightColor2(1.0f, 0.8f, 0.5f);
    glm::vec3 gLightPosition(5.0f, 4.0f, 4.0f);
    glm::vec3 gLightScale(1.0f);
    glm::vec3 gLightPosition2(-5.0f, 4.0f, -4.0f);
    glm::vec3 gLightScale2(1.0f);

}

bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateShape1(GLMesh& mesh);
void UCreateShape2(GLMesh& mesh);
void UCreateShape3(GLMesh& mesh);
void UCreateShape4(GLMesh& mesh);
void UCreateLight(GLMesh& mesh);
void UCreateBase(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
bool UCreateTextureClamp(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);

//Sets vertex information
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal;
out vec3 vertexFragmentPos;
out vec2 vertexTextureCoordinate;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

//positioning and vertex information
void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f);
    vertexFragmentPos = vec3(model * vec4(position, 1.0f));
    vertexNormal = mat3(transpose(inverse(model))) * normal;
    vertexTextureCoordinate = textureCoordinate;
}
);

const GLchar* fragmentShaderSource = GLSL(440,
    in vec3 vertexNormal; 
in vec3 vertexFragmentPos;
in vec2 vertexTextureCoordinate;
out vec4 fragmentColor;
uniform sampler2D uTextureBase;
uniform sampler2D uTextureExtra;
uniform bool multipleTextures;
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightColor2;
uniform vec3 lightPos;
uniform vec3 lightPos2;
uniform vec3 viewPosition;
uniform sampler2D uTexture;
uniform vec2 uvScale;

void main()
{
    float ambientStrength = 0.2f;
    vec3 ambient = ambientStrength * lightColor * lightColor2;
    vec3 norm = normalize(vertexNormal);
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos);
    vec3 lightDirection2 = normalize(lightPos2 - vertexFragmentPos);
    float impact = max(dot(norm, lightDirection), 0.0);
    float impact2 = max(dot(norm, lightDirection2), 0.0);
    vec3 diffuse = impact * lightColor;
    vec3 diffuse2 = impact2 * lightColor2;
    float specularIntensity = 10.0f;
    float specularIntensity2 = 0.1f;
    float highlightSize = 5.0f;
    float highlightSize2 = 30.0f;
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos);
    vec3 reflectDir = reflect(-lightDirection, norm);
    vec3 reflectDir2 = reflect(-lightDirection2, norm);
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    float specularComponent2 = pow(max(dot(viewDir, reflectDir2), 0.0), highlightSize2);
    vec3 specular = specularIntensity * specularComponent * lightColor;
    vec3 specular2 = specularIntensity2 * specularComponent2 * lightColor2;
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
    vec3 fullDiffuse = diffuse + diffuse2;
    vec3 fullSpecular = specular + specular2;
    vec3 phong = (ambient + fullDiffuse + fullSpecular) * textureColor.xyz;
    fragmentColor = vec4(phong, 1.0);
}
);

const GLchar* lightVertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f);
}
);

const GLchar* lightFragmentShaderSource = GLSL(440,
    out vec4 fragmentColor;

void main()
{
    fragmentColor = vec4(1.0f);
}
);
const GLchar* lightVertexShaderSource2 = GLSL(440,
    layout(location = 0) in vec3 position;
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f);
}
);

const GLchar* lightFragmentShaderSource2 = GLSL(440,
    out vec4 fragmentColor;

void main()
{
    fragmentColor = vec4(1.0f);
}
);
//flips image to show it in correct angle
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;
        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}
//Sets creation and deletes when done
int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;
    UCreateShape1(gShape1);
    UCreateShape2(gShape2);
    UCreateShape3(gShape3);
    UCreateShape4(gShape4);
    UCreateLight(gLight);
    UCreateLight(gLight2);
    UCreateBase(gBase);
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, gLightProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(lightVertexShaderSource2, lightFragmentShaderSource2, gLightProgram2Id))
        return EXIT_FAILURE;
    //Sets images sued for textures
    const char* texFilename = "W.jpg";
    if (!UCreateTexture(texFilename, gTex1))
    {
        cout << "Texture issues prevented program from loading " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "R.jpg";
    if (!UCreateTexture(texFilename, gTex2))
    {
        cout << "Texture issues prevented program from loading " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "C.jpg";
    if (!UCreateTexture(texFilename, gTex3))
    {
        cout << "Texture issues prevented program from loading " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "W2.jpg";
    if (!UCreateTexture(texFilename, gTex4))
    {
        cout << "Texture issues prevented program from loading " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "M.jpg";
    if (!UCreateTexture(texFilename, gTex5))
    {
        cout << "Texture issues prevented program from loading " << texFilename << endl;
        return EXIT_FAILURE;
    }
    //Sets main information including time
    glUseProgram(gProgramId);
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture1"), 0);
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture2"), 1);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    while (!glfwWindowShouldClose(gWindow))
    {
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;
        UProcessInput(gWindow);
        URender();
        glfwPollEvents();
    }
    //Initaliates destoy features after use and exits program
    UDestroyMesh(gShape1);
    UDestroyMesh(gShape2);
    UDestroyMesh(gShape3);
    UDestroyMesh(gShape4);
    UDestroyMesh(gLight);
    UDestroyMesh(gLight2);
    UDestroyMesh(gBase);
    UDestroyTexture(gTex1);
    UDestroyTexture(gTex2);
    UDestroyTexture(gTex3);
    UDestroyTexture(gTex4);
    UDestroyTexture(gTex5);
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLightProgramId);
    UDestroyShaderProgram(gLightProgram2Id);
    exit(EXIT_SUCCESS);
}
//Initiates/calls different parameters that are applied to project
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create viewing window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();
    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }
    cout << "OpenGL Version: " << glGetString(GL_VERSION) << endl;
    return true;
}

// moves image when specific buttons are applied
void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    bool keypress = false;
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
        keypress = true;
    }
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
        keypress = true;
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
        keypress = true;
    }
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
        keypress = true;
    }
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
        keypress = true;
    }
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(UP, gDeltaTime);
        keypress = true;
    }
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
    {
        ortho = !ortho;
    }
    if (keypress)
    {
        double x, y;
        glfwGetCursorPos(window, &x, &y);
    }
}
// allows for window rezise for different screen sizes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}
//Renders image with specifics applied
void URender()
{
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram(gProgramId);
    glm::mat4 model = glm::translate(gCenterPosition) * glm::scale(gCenterScale);
    glm::mat4 view = gCamera.GetViewMatrix();
    glm::mat4 projection;
    if (ortho) {
        float scale = 50;
        projection = glm::ortho(-(800.0f / scale), 800.0f / scale, -(600.0f / scale), (600.0f / scale), 4.5f, 6.5f);
    }
    else {
        projection = glm::perspective(glm::radians(gCamera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    //Stes specific settigns for each shape
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");
    GLint lightColorLoc2 = glGetUniformLocation(gProgramId, "lightColor2");
    GLint lightPositionLoc2 = glGetUniformLocation(gProgramId, "lightPos2");
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
    glUniform3f(lightPositionLoc2, gLightPosition2.x, gLightPosition2.y, gLightPosition2.z);
    glUniform3f(lightColorLoc2, gLightColor2.r, gLightColor2.g, gLightColor2.b);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glActiveTexture(GL_TEXTURE0);
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glActiveTexture(GL_TEXTURE0);
    //Sets information for candy cane box shape
    glBindTexture(GL_TEXTURE_2D, gTex1);
    model = glm::translate(gShape1Position) * glm::scale(gShape1Scale);
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glBindVertexArray(gShape1.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex2);
    glDrawElements(GL_TRIANGLES, gShape1.nIndices, GL_UNSIGNED_SHORT, NULL);
    //Sets information for Tree Trunk SHape
    model = glm::translate(gShape2Position) * glm::scale(gShape2Scale);
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glBindVertexArray(gShape2.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex3);
    glDrawElements(GL_TRIANGLES, gShape2.nIndices, GL_UNSIGNED_SHORT, NULL);
    //Sets information for Tree top shape
    model = glm::translate(gShape3Position) * glm::scale(gShape3Scale);
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glBindVertexArray(gShape3.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex4);
    glDrawElements(GL_TRIANGLES, gShape3.nIndices, GL_UNSIGNED_SHORT, NULL);
    //Sets information for speaker shape
    model = glm::translate(gShape4Position) * glm::scale(gShape4Scale);
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glBindVertexArray(gShape4.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex5);
    glDrawElements(GL_TRIANGLES, gShape4.nIndices, GL_UNSIGNED_SHORT, NULL);


    
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    //Sets information for Base shape
    glBindVertexArray(gBase.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex1);
    glDrawElements(GL_TRIANGLES, gBase.nIndices, GL_UNSIGNED_SHORT, NULL);
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glActiveTexture(GL_TEXTURE0);
    
    glBindTexture(GL_TEXTURE_2D, gTex1);
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex1);
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex1);
    //Sets information for Light One
    glUseProgram(gLightProgramId);
    model = glm::translate(gLightPosition) * glm::scale(gLightScale);
    modelLoc = glGetUniformLocation(gLightProgramId, "model");
    viewLoc = glGetUniformLocation(gLightProgramId, "view");
    projLoc = glGetUniformLocation(gLightProgramId, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glBindVertexArray(gLight.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex1);
    glDrawElements(GL_TRIANGLES, gLight.nIndices, GL_UNSIGNED_SHORT, NULL);
    //Sets information for Light Two
    glUseProgram(gLightProgram2Id);
    model = glm::translate(gLightPosition2) * glm::scale(gLightScale2);
    modelLoc = glGetUniformLocation(gLightProgram2Id, "model");
    viewLoc = glGetUniformLocation(gLightProgram2Id, "view");
    projLoc = glGetUniformLocation(gLightProgram2Id, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glBindVertexArray(gLight2.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTex1);
    glDrawElements(GL_TRIANGLES, gLight2.nIndices, GL_UNSIGNED_SHORT, NULL);
    glBindVertexArray(0);
    glUseProgram(0);
    glfwSwapBuffers(gWindow);
}

//Creates Shape for candy cane box
void UCreateShape1(GLMesh& mesh)
{
    GLfloat verts[] = {
        // vertex Points       // Colors r,g,b,a        //Textures
        1.3f,0.0f,0.7f,        1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        1.6f,0.0f,0.4f,        1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        1.3f,0.8f,0.7f,        1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
        1.6f,0.8f,0.4f,        1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

        1.6f,0.0f,0.4f,        1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        0.5f,0.0f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        1.6f,0.8f,0.4f,        1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
        0.5f,0.8f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

        0.2f,0.0f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        0.5f,0.0f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        0.2f,0.8f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        0.5f,0.8f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,

        1.3f,0.0f,0.7f,        1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        0.2f,0.0f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        1.3f,0.8f,0.7f,        1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        0.2f,0.8f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,

        1.3f,0.8f,0.7f,        1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        1.6f,0.8f,0.4f,        1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        0.2f,0.8f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        0.5f,0.8f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
    };
    // Shapes indice location
    GLushort indices[] = {
         0,1,2,
        1,2,3,

        4,5,6,
        5,6,7,

        8,9,10,
        9,10,11,

        12,13,14,
        13,14,15,

        16,17,18,
        17,18,19,
    };
    //Specific inputs for shape
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}
//Creates Shape for Tree Trunk 
void UCreateShape2(GLMesh& mesh)
{
    GLfloat verts[] = {
        // vertex Points       // Colors r,g,b,a        //Textures
        0.0f,   1.6f, 0.0f,   1.0f, 0.0f, 0.0f, 1.0f,  0.5f, 0.5f,
        0.5f,  0.6f, 0.5f,   0.0f, 1.0f, 0.0f, 1.0f,  0.0f, 0.0f,
       -0.5f,  0.6f, 0.5f,   0.0f, 0.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.5f,  0.6f, -0.5f,  1.0f, 1.0f, 0.0f, 1.0f,  0.0f, 1.0f,
       -0.5,   0.6f, -0.5f,  1.0f, 0.0f, 1.0f, 1.0f,  0.0f, 0.0f,

    };
    // Shapes indice location
    GLushort indices[] = {
        1, 0, 3,
        3, 0, 4,
        4, 0, 2,
        2, 0, 1,
        2, 1, 3,
        2, 4, 3,
    };
    //Specific inputs for shape
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}
//Creates Shape for Tree Top
void UCreateShape3(GLMesh& mesh)
{
    GLfloat verts[] = {
        // vertex Points       // Colors r,g,b,a        //Textures
        -0.2f,0.0f,-0.2f,      1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        -0.2f,0.0f,0.2f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         0.2f,0.0f,-0.2f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
         0.2f,0.0f,0.2f,       1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

        -0.2f,0.6f,-0.2f,     1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        -0.2f,0.6f,0.2f,      1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         0.2f,0.6f,-0.2f,     1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
         0.2f,0.6f,0.2f,      1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

         0.2f,0.6f,-0.2f,     1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        -0.2f,0.6f,-0.2f,     1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         0.2f,0.0f,-0.2f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        -0.2f,0.0f,-0.2f,      1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,

        -0.2f,0.0f,0.2f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
         0.2f,0.0f,0.2f,       1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        -0.2f,0.6f,0.2f,      1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         0.2f,0.6f,0.2f,      1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

         0.2f,0.0f,-0.2f,      1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
         0.2f,0.0f,0.2f,       1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
         0.2f,0.6f,-0.2f,     1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         0.2f,0.6f,0.2f,      1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

        -0.2f,0.0f,-0.2f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        -0.2f,0.0f,0.2f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        -0.2f,0.6f,-0.2f,     1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        -0.2f,0.6f,0.2f,      1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
    };
    // Shapes indice location
    GLushort indices[] = {
       0,1,2,
        1,2,3,

        4,5,6,
        5,6,7,

        8,9,10,
        9,10,11,

        12,13,14,
        13,14,15,

        16,17,18,
        17,18,19,

        20,21,22,
        21,22,23,
    };
    //Specific inputs for shape
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}
//Creates Shape for Speaker
void UCreateShape4(GLMesh& mesh)
{
    GLfloat verts[] = {
        // vertex Points       // Colors r,g,b,a        //Textures
        -1.5f,0.0f,0.5f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
        -1.0f,0.0f,0.5f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.5f,0.2f,0.5f,      1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL
         -1.0f,0.2f,0.5f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,//TR

         -1.0f,0.0f,0.5f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
        -0.7f,0.0f,0.0f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.0f,0.2f,0.5f,      1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL
         -0.7f,0.2f,0.0f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,//TR

         -0.7f, 0.0f,0.0f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -1.0f, 0.0f, -0.5f,      1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -0.7f, 0.2f, 0.0f,    1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL
         -1.0f, 0.2f, -0.5f,    1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,//TR

         -1.0f, 0.0f,-0.5f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -1.5f,  0.0f, -0.5f,      1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.0f,  0.2f, -0.5f,    1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL
         -1.5f,  0.2f, -0.5f,    1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,//TR

         -1.5f, 0.0f,-0.5f,     1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -1.8f, 0.0f, 0.0f,     1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.5f, 0.2f, -0.5f,   1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL
         -1.8f, 0.2f, -0.0f,    1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,//TR

         -1.8f, 0.0f,0.0f,   1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -1.5f,  0.0f, 0.5f,    1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.8f,  0.2f, -0.0f,   1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL
         -1.5f,  0.2f, 0.5f,    1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,//TR

         -1.5f, 0.2f,0.5f,   1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -1.0f, 0.2f, 0.5f,    1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.25f, 0.2f, 0.0f,   1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL

         -1.0f, 0.2f,0.5f,   1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -0.7f, 0.2f, 0.0f,    1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.25f, 0.2f, 0.0f,   1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL

         -0.7f, 0.2f, 0.0f,   1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -1.0f, 0.2f, -0.5f,    1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.25f, 0.2f, 0.0f,   1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL

         -1.0f, 0.2f,-0.5f,   1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -1.5f, 0.2f, -0.5f,    1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.25f, 0.2f, 0.0f,   1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL

         -1.5f, 0.2f,-0.5f,   1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
         -1.8f, 0.2f, -0.0f,    1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
         -1.25f, 0.2f, 0.0f,   1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL

           -1.5f, 0.2f,0.5f,   1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f, //BL
           -1.8f, 0.2f, -0.0f,    1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,//BR
           -1.25f, 0.2f, 0.0f,  1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,//TL




    };
    // Shapes indice location
    GLushort indices[] = {
       0,1,2,
        1,2,3,

        4,5,6,
        5,6,7,

        8,9,10,
        9,10,11,

        12,13,14,
        13,14,15,

        16,17,18,
        17,18,19,

        20,21,22,
        21,22,23,

        24,25,26,

        27,28,29,

        30,31,32,

        33,34,35,

        36,37,38,

        39,40,41
    };
    //Specific inputs for shape
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}
//Creates Shape for Light One
// Creates shape for Light source
void UCreateLight(GLMesh& mesh)
{
    GLfloat verts[] = {

        // vertex Points       // Colors r,g,b,a        //Textures
        1.3f,0.0f,0.7f,        1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        1.6f,0.0f,0.4f,        1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        1.3f,0.8f,0.7f,        1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
        1.6f,0.8f,0.4f,        1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

        1.6f,0.0f,0.4f,        1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        0.5f,0.0f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        1.6f,0.8f,0.4f,        1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
        0.5f,0.8f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

        0.2f,0.0f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        0.5f,0.0f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        0.2f,0.8f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        0.5f,0.8f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,

        1.3f,0.0f,0.7f,        1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        0.2f,0.0f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        1.3f,0.8f,0.7f,        1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        0.2f,0.8f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,

        1.3f,0.8f,0.7f,        1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        1.6f,0.8f,0.4f,        1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        0.2f,0.8f,-0.4f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        0.5f,0.8f,-0.7f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
    };

    GLushort indices[] = {
         0,1,2,
        1,2,3,

        4,5,6,
        5,6,7,

        8,9,10,
        9,10,11,

        12,13,14,
        13,14,15,

        16,17,18,
        17,18,19,

    };
    //Specific inputs for shape
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}
//Creates shape for Base
void UCreateBase(GLMesh& mesh)
{
    GLfloat verts[] = {
        // vertex Points       // Colors r,g,b,a        //Textures
        -2.0f,0.0f,-1.0f,      1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        -2.0f,0.0f,1.0f,       1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         2.0f,0.0f,-1.0f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
         2.0f,0.0f,1.0f,       1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

        -2.0f,-0.2f,-1.0f,     1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        -2.0f,-0.2f,1.0f,      1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         2.0f,-0.2f,-1.0f,     1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
         2.0f,-0.2f,1.0f,      1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

         2.0f,-0.2f,-1.0f,     1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        -2.0f,-0.2f,-1.0f,     1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         2.0f,0.0f,-1.0f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        -2.0f,0.0f,-1.0f,      1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,

        -2.0f,0.0f,1.0f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
         2.0f,0.0f,1.0f,       1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        -2.0f,-0.2f,1.0f,      1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         2.0f,-0.2f,1.0f,      1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

         2.0f,0.0f,-1.0f,      1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
         2.0f,0.0f,1.0f,       1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
         2.0f,-0.2f,-1.0f,     1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
         2.0f,-0.2f,1.0f,      1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,

        -2.0f,0.0f,-1.0f,      1.0f,0.0f,0.0f,0.0f,     0.0f,0.0f,
        -2.0f,0.0f,1.0f,       1.0f,0.0f,0.0f,0.0f,     1.0f,0.0f,
        -2.0f,-0.2f,-1.0f,     1.0f,0.0f,0.0f,0.0f,     0.0f,1.0f,
        -2.0f,-0.2f,1.0f,      1.0f,0.0f,0.0f,0.0f,     1.0f,1.0f,
    };
// Shapes indice location
GLushort indices[] = {
   0,1,2,
    1,2,3,

    4,5,6,
    5,6,7,

    8,9,10,
    9,10,11,

    12,13,14,
    13,14,15,

    16,17,18,
    17,18,19,

    20,21,22,
    21,22,23,
};
//Inputs shapes specfic information(color, point lcoations, number of inputs, etc.)
const GLuint floatsPerVertex = 3;
const GLuint floatsPerColor = 4;
const GLuint floatsPerUV = 2;
glGenVertexArrays(1, &mesh.vao);
glBindVertexArray(mesh.vao);
glGenBuffers(2, mesh.vbos);
glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);
glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
glEnableVertexAttribArray(0);
glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
glEnableVertexAttribArray(1);
glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
glEnableVertexAttribArray(2);
}
//Destroys mesh information after use
void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}
//Destroys texture information after use
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);
        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Image having issues with " << channels << " channels" << endl;
            return false;
        }
        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);
        return true;
    }
    return false;
}
//Esnures textures are ebign applied correctly to shape
bool UCreateTextureClamp(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);
        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Image having issues with " << channels << " channels" << endl;
            return false;
        }
        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);
        return true;
    }
    return false;
}
//Destroys texture after use
void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}
// Creates shader infromation for usage
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    int success = 0;
    char infoLog[512];
    programId = glCreateProgram();
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);
    glCompileShader(vertexShaderId);
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
       return false;
    }
    glCompileShader(fragmentShaderId);
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
        return false;
    }

    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);
    glLinkProgram(programId);
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
        return false;
    }
    glUseProgram(programId);
    return true;
}
// Creates mouse position information for use
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }
    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos;
    gLastX = xpos;
    gLastY = ypos;
    gCamera.ProcessMouseMovement(xoffset, yoffset);
}
// Creates mouse scroll information for use
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}
// Creates mouse button clicks information for use
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left button pressed" << endl;
        else
            cout << "Left button released" << endl;
    }
    break;
    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle button pressed" << endl;
        else
            cout << "Middle button released" << endl;
    }
    break;
    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right button pressed" << endl;
        else
            cout << "Right button released" << endl;
    }
    break;
    default:
        cout << "Unhandled button event" << endl;
        break;
    }
}
// Destroys shader information after use
void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}